package com.example.lovecalculator;

import android.renderscript.Sampler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Random;

import pl.droidsonroids.gif.GifImageView;

public class MainActivity extends AppCompatActivity {
    EditText male, female;
    TextView tv;
    String result, mi="92%", no="10%";
    GifImageView jaan, lovepic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void showResult(View v){
        female=(EditText) findViewById(R.id.editText1);
        male =(EditText) findViewById(R.id.editText2);
        tv = (TextView) findViewById(R.id.textView);
        jaan = (GifImageView) findViewById(R.id.myJaan);
        lovepic = (GifImageView) findViewById(R.id.lovepic);


        String f=female.getText().toString();
        String m=male.getText().toString();


        String string1 = new String("dev ");
        String string2 = new String("dev");


        String string6 = new String("shailu ");
        String string7 = new String("shailendra ");
        String string8 = new String("shailu");
        String string9 = new String("shailendra");



        String sum =m+f;
        sum=sum.toLowerCase();
        int value=sum.hashCode();

        Random random = new Random(value);
        result=((random.nextInt(100)+1)+"%");
        if (f.equals("")||m.equals("")){
            Toast.makeText(MainActivity.this,"please fill the entry first", Toast.LENGTH_SHORT).show();
        } else if(m.equalsIgnoreCase(string6)|| m.equalsIgnoreCase(string7)||m.equalsIgnoreCase(string8)||m.equalsIgnoreCase(string9)){
            jaan.setVisibility(View.VISIBLE);
            lovepic.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
            tv.setText(mi);

        }else if(m.equalsIgnoreCase(string1)|| m.equalsIgnoreCase(string2)){
            jaan.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
            tv.setText(no);

        }else if(tv.equals("90")||tv.equals("91")||tv.equals("92")||tv.equals("93")||tv.equals("94")||tv.equals("95")||tv.equals("96")||tv.equals("97")||
                tv.equals("98")||tv.equals("99")||tv.equals("100")){
            jaan.setVisibility(View.VISIBLE);
            lovepic.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
            tv.setText(result);

        }else {
            jaan.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
            tv.setText(result);
        }
    }
}
